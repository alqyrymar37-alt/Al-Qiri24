package com.alqiri.legend

import android.Manifest
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.Looper
import android.os.PowerManager
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.telephony.SmsManager
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

// ---- Palette matched to the app icon: teal ring + orange tail on a near-black backdrop ----
private class Palette(
    val dark: Boolean,
    val bg: Color, val sidebar: Color, val panel: Color, val userBubble: Color, val border: Color,
    val text: Color, val muted: Color, val accent: Color, val secondary: Color, val onAccent: Color, val danger: Color
)

private val LightPalette = Palette(
    dark = false, bg = Color(0xFFFAF8F5), sidebar = Color(0xFFF1EEE9), panel = Color(0xFFFFFFFF),
    userBubble = Color(0xFFE3F5F1), border = Color(0xFFE4E0D8), text = Color(0xFF1B1A20),
    muted = Color(0xFF6F6D76), accent = Color(0xFFF2793C), secondary = Color(0xFF1F9E93),
    onAccent = Color(0xFFFFFFFF), danger = Color(0xFFB3261E)
)
private val DarkPalette = Palette(
    dark = true, bg = Color(0xFF121116), sidebar = Color(0xFF0E0D12), panel = Color(0xFF1C1B22),
    userBubble = Color(0xFF123230), border = Color(0xFF2A2932), text = Color(0xFFF3F2F0),
    muted = Color(0xFF9C9AA6), accent = Color(0xFFFE7A30), secondary = Color(0xFF3ADDBF),
    onAccent = Color(0xFFFFFFFF), danger = Color(0xFFE5484D)
)
private val LocalPalette = staticCompositionLocalOf { LightPalette }

@Composable
private fun QiriTheme(content: @Composable () -> Unit) {
    val p = if (isSystemInDarkTheme()) DarkPalette else LightPalette
    val scheme = if (p.dark) {
        darkColorScheme(
            primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text,
            surface = p.panel, onSurface = p.text, secondary = p.muted, error = p.danger
        )
    } else {
        lightColorScheme(
            primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text,
            surface = p.panel, onSurface = p.text, secondary = p.muted, error = p.danger
        )
    }
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

class MainActivity : ComponentActivity() {

    private class Msg(val fromUser: Boolean, val text: String)
    private class Pending(val text: String, val result: CompletableDeferred<Boolean>)

    // ---- UI state ----
    private val messages = mutableStateListOf<Msg>()
    private var busy by mutableStateOf(false)
    private var listening by mutableStateOf(false)
    private var voiceOut by mutableStateOf(true)
    private var pending by mutableStateOf<Pending?>(null)
    private var inputText by mutableStateOf("")
    private var wakeOn by mutableStateOf(false)
    private var showAttachMenu by mutableStateOf(false)

    private lateinit var brain: Brain
    private val tools by lazy { PhoneTools(applicationContext, { speak(it) }, { confirmUi(it) }) }
    private var currentJob: Job? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    private val micLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) beginVoiceInput() else addAssistant("ما اقدر اسمعك بدون صلاحية المايك يا زعيم 🎤 فعّلها من القائمة ← منح الصلاحيات.")
    }
    private var pendingCameraUri: Uri? = null
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) submitImage(uri, "صورة من المعرض")
    }
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) submitImage(uri, "صورة بالكاميرا") else if (!success) addAssistant("ما التقطت صورة يا زعيم.")
    }
    private val textFileLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) submitTextFile(uri)
    }
    private val cameraPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCamera() else addAssistant("لازم تعطيني صلاحية الكاميرا 📷 من القائمة ← منح الصلاحيات.")
    }

    // =====================================================================
    //  Lifecycle
    // =====================================================================
    override fun attachBaseContext(newBase: Context) {
        val lang = SecureStore.appLocale(newBase)
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val config = Configuration(newBase.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        brain = Brain(applicationContext, tools)
        val uiDir = if (SecureStore.appLocale(this) == "en") LayoutDirection.Ltr else LayoutDirection.Rtl

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar"))   // Qiri always speaks Yemeni Arabic, regardless of UI language
                ttsReady = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setSpeechRate(0.95f)
                applySavedVoice()
            }
        }

        setContent {
            QiriTheme {
                CompositionLocalProvider(LocalLayoutDirection provides uiDir) { QiriScreen() }
            }
        }

        val missing = runtimePermissions().filter { !has(it) }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        WakeService.paused = true          // the screen is open: the background listener steps aside
        wakeOn = WakeService.running
    }

    override fun onPause() {
        WakeService.paused = false         // app hidden: "يا قيري" listens again
        super.onPause()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun runtimePermissions(): List<String> = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.READ_SMS)
        add(Manifest.permission.READ_CALL_LOG)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        add(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 32) add(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT <= 29) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun toggleWake() {
        if (WakeService.running) {
            stopService(Intent(this, WakeService::class.java))
            wakeOn = false
            addAssistant("طفّيت وضع «يا قيري» 🔕")
            return
        }
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            addAssistant("لازم تعطيني صلاحية المايك أول 🎤 وبعدين شغّل الوضع من جديد.")
            permLauncher.launch(runtimePermissions().toTypedArray())
            return
        }
        try {
            ContextCompat.startForegroundService(this, Intent(this, WakeService::class.java))
            wakeOn = true
            addAssistant(
                "شغّلت وضع «يا قيري» 🎙️ اطلع من التطبيق وناديني: «يا قيري وين جوالي».\n" +
                    "🔒 لو الجوال مقفول بقفل ما انفّذ شي (حماية لك)، افتحه بنفسك. ولو تبغاه يشتغل وهو مقفول، فعّل Smart Lock من اعدادات الجوال."
            )
            requestBatteryExemption()
        } catch (e: Exception) {
            addAssistant("ما قدرت اشغّل الاستماع: ${e.message}")
        }
    }

    private fun requestBatteryExemption() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        } catch (_: Exception) {}
    }

    private fun openAllFilesAccess() {
        if (Build.VERSION.SDK_INT < 30) return
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Exception) {}
        }
    }

    // =====================================================================
    //  Chat plumbing
    // =====================================================================
    private fun addUser(t: String) { messages.add(Msg(true, t)) }
    private fun addAssistant(t: String) { messages.add(Msg(false, t)) }

    private fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        addUser(t)
        inputText = ""
        busy = true
        currentJob = lifecycleScope.launch {
            try {
                val reply = withContext(Dispatchers.Default) { brain.handle(t) }
                addAssistant(reply)
                speak(reply)
            } catch (e: CancellationException) {
                addAssistant("وقفت يا زعيم ✋")
                throw e
            } catch (e: Exception) {
                addAssistant("صار خطأ يا زعيم: ${e.message}")
            } finally {
                busy = false
            }
        }
    }

    private fun launchCamera() {
        if (busy) return
        if (!has(Manifest.permission.CAMERA)) {
            cameraPermLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        try {
            val dir = File(cacheDir, "captures").apply { mkdirs() }
            val file = File(dir, "shot_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            pendingCameraUri = uri
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            addAssistant("ما قدرت افتح الكاميرا: ${e.message}")
        }
    }

    /** Downscales + JPEG-compresses so the image stays small enough to send quickly. */
    private fun encodeImage(uri: Uri): Pair<String, String>? {
        return try {
            val input = contentResolver.openInputStream(uri) ?: return null
            val original = input.use { BitmapFactory.decodeStream(it) } ?: return null
            val maxSide = 1280
            val scale = minOf(1f, maxSide.toFloat() / maxOf(original.width, original.height))
            val bmp = if (scale < 1f) Bitmap.createScaledBitmap(original, (original.width * scale).toInt(), (original.height * scale).toInt(), true) else original
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP) to "image/jpeg"
        } catch (e: Exception) {
            null
        }
    }

    private fun submitImage(uri: Uri, label: String) {
        if (busy) return
        val caption = inputText.trim()
        addUser(if (caption.isNotBlank()) "📎 $label — $caption" else "📎 $label")
        inputText = ""
        busy = true
        currentJob = lifecycleScope.launch {
            try {
                val encoded = withContext(Dispatchers.IO) { encodeImage(uri) }   // decode+compress off the UI thread
                if (encoded == null) {
                    addAssistant("ما قدرت اقرا الصورة يا زعيم، جرّب صورة ثانية.")
                    return@launch
                }
                val (b64, mime) = encoded
                val reply = withContext(Dispatchers.Default) { brain.handle(caption, b64, mime) }
                addAssistant(reply)
                speak(reply)
            } catch (e: CancellationException) {
                addAssistant("وقفت يا زعيم ✋")
                throw e
            } catch (e: Exception) {
                addAssistant("صار خطأ يا زعيم: ${e.message}")
            } finally {
                busy = false
            }
        }
    }

    /** .txt attachments are read as plain text and sent as context (no OCR needed for these). */
    private fun submitTextFile(uri: Uri) {
        if (busy) return
        val text = try {
            contentResolver.openInputStream(uri)?.use { it.bufferedReader().readText() }
        } catch (e: Exception) { null }
        if (text.isNullOrBlank()) {
            addAssistant("ما قدرت اقرا الملف يا زعيم. يدعم القيري حالياً ملفات نصية (txt) والصور مباشرة — لملف PDF او Word صوّر الصفحة بالكاميرا وارسلها لي.")
            return
        }
        val caption = inputText.trim()
        val combined = (if (caption.isNotBlank()) "$caption\n\n" else "") + "محتوى الملف المرفق:\n" + text.take(12000)
        addUser(if (caption.isNotBlank()) "📎 ملف نصي — $caption" else "📎 ملف نصي مرفق")
        inputText = ""
        busy = true
        currentJob = lifecycleScope.launch {
            try {
                val reply = withContext(Dispatchers.Default) { brain.handle(combined) }
                addAssistant(reply)
                speak(reply)
            } catch (e: CancellationException) {
                addAssistant("وقفت يا زعيم ✋")
                throw e
            } catch (e: Exception) {
                addAssistant("صار خطأ يا زعيم: ${e.message}")
            } finally {
                busy = false
            }
        }
    }

    private fun openAttachMenu() { showAttachMenu = true }

    private fun quickScan() {
        if (busy) return
        addUser("افحص جوالي")
        busy = true
        currentJob = lifecycleScope.launch {
            try {
                val r = withContext(Dispatchers.Default) { tools.scanPhoneSecurityUltimate() }
                addAssistant(r)
                speak(r)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                addAssistant("صار خطأ يا زعيم: ${e.message}")
            } finally {
                busy = false
            }
        }
    }

    private fun stopTask() {
        pending?.result?.complete(false)
        currentJob?.cancel()
        tts?.stop()
    }

    private fun newChat() {
        stopTask()
        messages.clear()
        brain.reset()
    }

    private fun showFolder(folder: String) {
        addAssistant("📁 ${folder.replace('_', ' ')}\n" + tools.getAlQiriFiles(folder))
    }

    private suspend fun confirmUi(text: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        pending = Pending(text, d)
        return try {
            withTimeoutOrNull(120_000L) { d.await() } ?: false
        } finally {
            pending = null
        }
    }

    // =====================================================================
    //  Voice in / voice out
    // =====================================================================
    private fun speak(text: String) {
        if (!voiceOut || !ttsReady) return
        val clean = text
            .replace(Regex("https?://\\S+"), " رابط ")
            .replace(Regex("[^\\p{L}\\p{N}\\p{P}\\p{M}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(350)
        if (clean.isNotEmpty()) tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "alqiri")
    }

    /** Every Arabic voice installed on this phone (varies by device/manufacturer — some have several). */
    private fun arabicVoices(): List<android.speech.tts.Voice> =
        try { tts?.voices?.filter { it.locale.language == "ar" && !it.isNetworkConnectionRequired }?.sortedBy { it.name } ?: emptyList() }
        catch (e: Exception) { emptyList() }

    private fun applySavedVoice() {
        val saved = SecureStore.ttsVoiceName(this) ?: return
        val v = tts?.voices?.firstOrNull { it.name == saved } ?: return
        try { tts?.voice = v } catch (e: Exception) {}
    }

    private fun setVoice(voice: android.speech.tts.Voice) {
        try {
            tts?.voice = voice
            SecureStore.setTtsVoiceName(this, voice.name)
            speak("جرّب كذا صوتي يا زعيم")
        } catch (e: Exception) {}
    }

    private fun toggleMic() {
        if (listening) {
            recognizer?.stopListening()
            listening = false
        } else {
            beginVoiceInput()
        }
    }

    private fun beginVoiceInput() {
        if (busy) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addAssistant("خدمة التعرف على الصوت مو متوفرة في جوالك يا زعيم. ثبّت «Google» او «خدمات الكلام من Google».")
            return
        }
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        tts?.stop()
        recognizer?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(error: Int) {
                listening = false
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        addAssistant("ما سمعتك زين يا زعيم 🎤 اضغط وعيدها.")
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                        addAssistant("التعرف على الصوت العربي يحتاج نت في بعض الجوالات. اكتب امرك او جرّب بعد شوي.")
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        addAssistant("صلاحية المايك ناقصة 🎤")
                    else -> {}
                }
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) submit(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) inputText = t
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer = rec
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-YE")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        rec.startListening(i)
    }

    // =====================================================================
    //  UI
    // =====================================================================
    @Composable
    private fun fieldColors() = LocalPalette.current.let { c ->
        OutlinedTextFieldDefaults.colors(
            focusedTextColor = c.text, unfocusedTextColor = c.text, cursorColor = c.accent,
            focusedBorderColor = c.accent, unfocusedBorderColor = c.border,
            focusedPlaceholderColor = c.muted, unfocusedPlaceholderColor = c.muted,
            focusedLabelColor = c.accent, unfocusedLabelColor = c.muted
        )
    }

    @Composable
    private fun QiriScreen() {
        val c = LocalPalette.current
        val drawerState = rememberDrawerState(DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        val listState = rememberLazyListState()
        var showSettings by remember { mutableStateOf(false) }
        var showParental by remember { mutableStateOf(false) }
        var showHelp by remember { mutableStateOf(false) }
        var pendingTrustedConfirm by remember { mutableStateOf(false) }
        var callDetectorOn by remember { mutableStateOf(SecureStore.callDetectorOn(applicationContext)) }
        var trustedMode by remember { mutableStateOf(SecureStore.trustedMode(applicationContext)) }

        LaunchedEffect(messages.size, busy) {
            val target = messages.size - 1 + if (busy) 1 else 0
            if (target >= 0) listState.animateScrollToItem(target)
        }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = c.sidebar) {
                    Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.ic_qiri_mono), null, Modifier.size(34.dp), colorFilter = ColorFilter.tint(c.secondary))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            stringResource(R.string.drawer_title), color = c.text,
                            fontFamily = FontFamily.Serif, fontSize = 20.sp, fontWeight = FontWeight.Medium
                        )
                    }
                    val itemColors = NavigationDrawerItemDefaults.colors(
                        unselectedContainerColor = c.sidebar, unselectedTextColor = c.text,
                        selectedContainerColor = c.userBubble, selectedTextColor = c.accent
                    )
                    FOLDERS.forEach { f ->
                        NavigationDrawerItem(
                            label = { Text(f.replace('_', ' ')) }, selected = false, colors = itemColors,
                            modifier = Modifier.padding(horizontal = 12.dp),
                            onClick = { scope.launch { drawerState.close() }; showFolder(f) }
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    NavigationDrawerItem(
                        label = { Text(stringResource(R.string.menu_settings)) }, selected = false, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = { scope.launch { drawerState.close() }; showSettings = true }
                    )
                    NavigationDrawerItem(
                        label = { Text(stringResource(R.string.menu_permissions)) }, selected = false, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = {
                            scope.launch { drawerState.close() }
                            permLauncher.launch(runtimePermissions().toTypedArray())
                        }
                    )
                    NavigationDrawerItem(
                        label = { Text(stringResource(R.string.menu_allfiles)) }, selected = false, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = { scope.launch { drawerState.close() }; openAllFilesAccess() }
                    )
                    NavigationDrawerItem(
                        label = { Text(if (wakeOn) "🎙️ ايقاف وضع «يا قيري»" else "🎙️ تشغيل وضع «يا قيري» (استماع دائم)") },
                        selected = wakeOn, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = { scope.launch { drawerState.close() }; toggleWake() }
                    )
                    NavigationDrawerItem(
                        label = { Text(stringResource(R.string.menu_apps_access)) }, selected = QiriAccessibilityService.connected.collectAsState().value, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = {
                            scope.launch { drawerState.close() }
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    )
                    NavigationDrawerItem(
                        label = { Text(stringResource(R.string.menu_parental)) }, selected = false, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = { scope.launch { drawerState.close() }; showParental = true }
                    )
                    NavigationDrawerItem(
                        label = { Text(if (callDetectorOn) "📵 ايقاف كاشف الارقام المجهولة" else "📵 تفعيل كاشف الارقام المجهولة") },
                        selected = callDetectorOn, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = {
                            if (!callDetectorOn && !has(Manifest.permission.READ_PHONE_STATE)) {
                                permLauncher.launch(runtimePermissions().toTypedArray())
                            }
                            callDetectorOn = !callDetectorOn
                            SecureStore.setCallDetectorOn(applicationContext, callDetectorOn)
                            scope.launch { drawerState.close() }
                            addAssistant(
                                if (callDetectorOn) "شغّلت كاشف الارقام المجهولة 📵 اي رقم غريب يتصل عليك، اكشفه واعلمك فوراً بإشعار."
                                else "طفّيت كاشف الارقام المجهولة."
                            )
                        }
                    )
                    NavigationDrawerItem(
                        label = { Text(if (trustedMode) "⚡ الوضع الموثوق: شغّال (بدون تأكيد)" else "⚡ تفعيل الوضع الموثوق (تنفيذ مباشر)") },
                        selected = trustedMode, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = {
                            scope.launch { drawerState.close() }
                            if (!trustedMode) {
                                pendingTrustedConfirm = true
                            } else {
                                trustedMode = false
                                SecureStore.setTrustedMode(applicationContext, false)
                                addAssistant("رجّعت التأكيد قبل الاتصال والرسائل ✅")
                            }
                        }
                    )
                    NavigationDrawerItem(
                        label = { Text(stringResource(R.string.menu_help)) }, selected = false, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = { scope.launch { drawerState.close() }; showHelp = true }
                    )
                    NavigationDrawerItem(
                        label = { Text(if (SecureStore.appLocale(applicationContext) == "en") "🌐 العربية" else "🌐 English") },
                        selected = false, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = {
                            val next = if (SecureStore.appLocale(applicationContext) == "en") "ar" else "en"
                            SecureStore.setAppLocale(applicationContext, next)
                            recreate()
                        }
                    )
                    NavigationDrawerItem(
                        label = { Text(stringResource(R.string.menu_newchat)) }, selected = false, colors = itemColors,
                        modifier = Modifier.padding(horizontal = 12.dp),
                        onClick = { scope.launch { drawerState.close() }; newChat() }
                    )
                }
            }
        ) {
            Column(Modifier.fillMaxSize().background(c.bg)) {
                // ---- Top bar ----
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { scope.launch { drawerState.open() } }) { Text("☰", color = c.text, fontSize = 22.sp) }
                    TextButton(onClick = { if (!busy) newChat() }, enabled = !busy) { Text("🧹", fontSize = 20.sp) }
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.ic_qiri_mono), null, Modifier.size(36.dp), colorFilter = ColorFilter.tint(c.secondary))
                        Spacer(Modifier.width(4.dp))
                        Column {
                            Text(
                                stringResource(R.string.app_name), color = c.text,
                                fontFamily = FontFamily.Serif, fontSize = 20.sp, fontWeight = FontWeight.Medium
                            )
                            Text(stringResource(R.string.app_subtitle), color = c.muted, fontSize = 11.sp)
                        }
                    }
                    TextButton(onClick = { voiceOut = !voiceOut; if (!voiceOut) tts?.stop() }) {
                        Text(if (voiceOut) "🔊" else "🔇", fontSize = 20.sp)
                    }
                    OutlinedButton(
                        onClick = { quickScan() }, enabled = !busy,
                        border = BorderStroke(1.dp, c.border), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) { Text(stringResource(R.string.scan_phone), color = c.text, fontSize = 13.sp) }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(c.border))

                // ---- Chat ----
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(), state = listState,
                    contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    items(messages) { m -> Bubble(m) }
                    if (busy) item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(18.dp), color = c.accent, strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.thinking), color = c.muted, fontSize = 13.sp)
                        }
                    }
                }

                // ---- Quick commands ----
                val chips = listOf(
                    Triple("وين جوالي", "وين جوالي؟", true),
                    Triple("ملفاتي", "ملفاتي", true),
                    Triple("من هذا الرقم", "من هذا الرقم ", false),
                    Triple("اتصل بـ", "اتصل بـ", false),
                    Triple("لخص", "لخص ", false)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(chips) { (label, cmd, auto) ->
                        Surface(
                            color = c.panel, shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, c.border),
                            modifier = Modifier.clickable { if (auto) { submit(cmd) } else { inputText = cmd } }
                        ) { Text(label, color = c.text, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)) }
                    }
                }

                // ---- Input: one rounded box with text + mic + execute ----
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                    color = c.panel, shape = RoundedCornerShape(28.dp), border = BorderStroke(1.dp, c.border)
                ) {
                    Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        val pasteClipboard = LocalClipboardManager.current
                        Box {
                            Button(
                                onClick = { openAttachMenu() }, shape = CircleShape, contentPadding = PaddingValues(0.dp),
                                modifier = Modifier.size(40.dp), enabled = !busy,
                                colors = ButtonDefaults.buttonColors(containerColor = c.sidebar, contentColor = c.text)
                            ) { Text("+", fontSize = 22.sp) }
                            DropdownMenu(expanded = showAttachMenu, onDismissRequest = { showAttachMenu = false }) {
                                DropdownMenuItem(text = { Text("📷 التقط صورة") }, onClick = { showAttachMenu = false; launchCamera() })
                                DropdownMenuItem(text = { Text("🖼️ صورة من المعرض") }, onClick = { showAttachMenu = false; galleryLauncher.launch("image/*") })
                                DropdownMenuItem(text = { Text("📄 ملف نصي (txt)") }, onClick = { showAttachMenu = false; textFileLauncher.launch("text/plain") })
                                DropdownMenuItem(
                                    text = { Text("📋 الصق من الحافظة") },
                                    onClick = {
                                        showAttachMenu = false
                                        val pasted = pasteClipboard.getText()?.text
                                        if (!pasted.isNullOrBlank()) inputText = (inputText + " " + pasted).trim()
                                    }
                                )
                            }
                        }
                        Spacer(Modifier.width(4.dp))
                        TextField(
                            value = inputText, onValueChange = { inputText = it },
                            modifier = Modifier.weight(1f), maxLines = 4,
                            placeholder = { Text(stringResource(R.string.input_hint), fontSize = 14.sp) },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                cursorColor = c.accent, focusedTextColor = c.text, unfocusedTextColor = c.text,
                                focusedPlaceholderColor = c.muted, unfocusedPlaceholderColor = c.muted
                            )
                        )
                        Button(
                            onClick = { toggleMic() }, shape = CircleShape, contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(44.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = if (listening) c.danger else c.sidebar, contentColor = c.text)
                        ) { Text(if (listening) "⏹" else "🎤", fontSize = 18.sp) }
                        Spacer(Modifier.width(6.dp))
                        Button(
                            onClick = { if (busy) stopTask() else submit(inputText) },
                            shape = RoundedCornerShape(22.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = if (busy) c.danger else c.accent, contentColor = c.onAccent)
                        ) { Text(stringResource(if (busy) R.string.stop_btn else R.string.execute_btn), fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }

        // ---- Approval dialog ----
        pending?.let { p ->
            AlertDialog(
                onDismissRequest = {},
                containerColor = c.panel, titleContentColor = c.text, textContentColor = c.text,
                title = { Text(stringResource(R.string.confirm_title), fontFamily = FontFamily.Serif) },
                text = { Text(p.text) },
                confirmButton = {
                    Button(onClick = { p.result.complete(true) }, colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)) {
                        Text(stringResource(R.string.confirm_yes))
                    }
                },
                dismissButton = { TextButton(onClick = { p.result.complete(false) }) { Text(stringResource(R.string.confirm_no), color = c.muted) } }
            )
        }

        // ---- Settings dialog ----
        if (showSettings) {
            var key by remember { mutableStateOf(SecureStore.apiKey(applicationContext)) }
            var model by remember { mutableStateOf(SecureStore.model(applicationContext)) }
            var baseUrl by remember { mutableStateOf(SecureStore.baseUrl(applicationContext)) }
            val detected = detectProvider(key.trim(), baseUrl.trim())
            AlertDialog(
                onDismissRequest = { showSettings = false },
                containerColor = c.panel, titleContentColor = c.text, textContentColor = c.text,
                title = { Text(stringResource(R.string.settings_title), fontFamily = FontFamily.Serif) },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            key, { key = it }, singleLine = true, colors = fieldColors(),
                            label = { Text(stringResource(R.string.settings_key)) },
                            visualTransformation = PasswordVisualTransformation()
                        )
                        Text(
                            if (key.isBlank()) "بدون مفتاح: القيري يشتغل بالاوامر الاساسية فقط"
                            else if (detected == Provider.CUSTOM && baseUrl.isBlank()) "🔍 نوع المفتاح غير معروف — بجرّبه مع Gemini تلقائياً"
                            else if (detected != null) "✅ تم التعرف عليه: ${detected.label}"
                            else "❌ ما تعرفت على نوع المفتاح، تأكد انه منسوخ كامل",
                            fontSize = 12.sp, color = if (detected != null || key.isBlank()) c.muted else c.danger
                        )
                        OutlinedTextField(
                            model, { model = it }, singleLine = true, colors = fieldColors(),
                            label = { Text(stringResource(R.string.settings_model)) },
                            placeholder = { Text(detected?.defaultModel ?: "تلقائي") }
                        )
                        if (detected == Provider.CUSTOM) {
                            OutlinedTextField(
                                baseUrl, { baseUrl = it }, singleLine = true, colors = fieldColors(),
                                label = { Text("رابط الخدمة (Base URL)") },
                                placeholder = { Text("https://...") }
                            )
                        }
                        Text(stringResource(R.string.settings_note), fontSize = 12.sp, color = c.muted)
                        OutlinedButton(
                            onClick = {
                                try {
                                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
                                } catch (_: Exception) {}
                            },
                            border = BorderStroke(1.dp, c.border)
                        ) { Text("🆓 احصل على مفتاح Gemini مجاني", color = c.accent, fontSize = 13.sp) }

                        HorizontalDivider(color = c.border)
                        Text("🔊 صوت القيري", fontSize = 13.sp, color = c.text, fontWeight = FontWeight.Bold)
                        val voices = remember { arabicVoices() }
                        if (voices.isEmpty()) {
                            Text(
                                "ما لقيت الا صوت عربي واحد على جوالك، فما فيه غيره للاختيار. لصوت افضل: الاعدادات ← الادارة العامة ← تحويل النص الى كلام ← نزّل بيانات صوت عربي اضافية.",
                                fontSize = 12.sp, color = c.muted
                            )
                        } else {
                            Text("جوالك فيه ${voices.size} صوت عربي، جرّبهم واختر الأقرب للهجتك:", fontSize = 12.sp, color = c.muted)
                            val current = SecureStore.ttsVoiceName(applicationContext)
                            voices.forEach { v ->
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    RadioButton(
                                        selected = v.name == current,
                                        onClick = { setVoice(v) },
                                        colors = RadioButtonDefaults.colors(selectedColor = c.accent)
                                    )
                                    Text(v.name.substringAfterLast('#').take(28), fontSize = 12.sp, color = c.text, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { setVoice(v) }) { Text("🔊 جرّب", color = c.secondary, fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            SecureStore.save(applicationContext, key.trim(), model.trim(), baseUrl.trim())
                            showSettings = false
                            addAssistant("تم حفظ الاعدادات ✅")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                    ) { Text(stringResource(R.string.settings_save)) }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text(stringResource(R.string.confirm_no), color = c.muted) } }
            )
        }

        // ---- Parental control dialog ----
        if (showParental) {
            var pinInput by remember { mutableStateOf("") }
            var newPin by remember { mutableStateOf("") }
            var unlocked by remember { mutableStateOf(!ParentalControl.hasPin(applicationContext)) }
            var enabled by remember { mutableStateOf(ParentalControl.isEnabled(applicationContext)) }
            var blocked by remember { mutableStateOf(ParentalControl.blockedApps(applicationContext)) }
            var installed by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
            var pinError by remember { mutableStateOf(false) }

            LaunchedEffect(Unit) {
                installed = withContext(Dispatchers.Default) {
                    val pm = packageManager
                    pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                        .filter { it.activityInfo.packageName != packageName }
                        .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                        .distinctBy { it.second }
                        .sortedBy { it.first }
                }
            }

            AlertDialog(
                onDismissRequest = { showParental = false },
                containerColor = c.panel, titleContentColor = c.text, textContentColor = c.text,
                title = { Text(stringResource(R.string.menu_parental), fontFamily = FontFamily.Serif) },
                text = {
                    if (!unlocked) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("ادخل الرمز السري عشان تفتح الرقابة الابوية 🔒", fontSize = 13.sp, color = c.muted)
                            OutlinedTextField(
                                pinInput, { pinInput = it; pinError = false }, singleLine = true, colors = fieldColors(),
                                label = { Text("الرمز السري") }, visualTransformation = PasswordVisualTransformation()
                            )
                            if (pinError) Text("الرمز غلط يا زعيم ❌", color = c.danger, fontSize = 12.sp)
                        }
                    } else {
                        val appsState = rememberLazyListState()
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("تفعيل الرقابة", fontSize = 15.sp, color = c.text)
                                Checkbox(
                                    checked = enabled,
                                    onCheckedChange = { enabled = it; ParentalControl.setEnabled(applicationContext, it) },
                                    colors = CheckboxDefaults.colors(checkedColor = c.accent)
                                )
                            }
                            Text(
                                if (ParentalControl.hasPin(applicationContext)) "الرمز محفوظ. اكتب رمز جديد لو تبغى تغيّره:" else "سوّ رمز سري (٤ ارقام على الاقل) عشان يحمي هذي الشاشة:",
                                fontSize = 12.sp, color = c.muted
                            )
                            OutlinedTextField(
                                newPin, { newPin = it }, singleLine = true, colors = fieldColors(),
                                label = { Text("رمز جديد") }, visualTransformation = PasswordVisualTransformation()
                            )
                            Button(
                                onClick = {
                                    if (newPin.length >= 4) {
                                        ParentalControl.setPin(applicationContext, newPin)
                                        newPin = ""
                                        addAssistant("تم حفظ رمز الرقابة الابوية ✅")
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = c.sidebar, contentColor = c.text)
                            ) { Text("حفظ الرمز") }
                            HorizontalDivider(color = c.border)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("التطبيقات المحظورة على الطفل:", fontSize = 13.sp, color = c.text)
                                if (installed.size > 5) {
                                    Row {
                                        TextButton(onClick = { scope.launch { appsState.animateScrollToItem(0) } }) { Text("⬆️", fontSize = 16.sp) }
                                        TextButton(onClick = { scope.launch { appsState.animateScrollToItem(maxOf(0, installed.lastIndex)) } }) { Text("⬇️", fontSize = 16.sp) }
                                    }
                                }
                            }
                            if (installed.isEmpty()) {
                                Text("...جاري تحميل التطبيقات", fontSize = 12.sp, color = c.muted)
                            } else {
                                LazyColumn(state = appsState, modifier = Modifier.heightIn(max = 260.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    items(installed) { (label, pkg) ->
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                        Checkbox(
                                            checked = pkg in blocked,
                                            onCheckedChange = { checked ->
                                                blocked = if (checked) blocked + pkg else blocked - pkg
                                                ParentalControl.setBlockedApps(applicationContext, blocked)
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = c.accent)
                                        )
                                        Text(label, fontSize = 13.sp, color = c.text)
                                    }
                                    }
                                }
                            }
                            if (!QiriAccessibilityService.connected.collectAsState().value) {
                                Text("⚠️ لازم تفعّل «التحكم بالتطبيقات» من القائمة عشان الحظر يشتغل فعلياً.", fontSize = 12.sp, color = c.danger)
                            }
                        }
                    }
                },
                confirmButton = {
                    if (!unlocked) {
                        Button(
                            onClick = { if (ParentalControl.checkPin(applicationContext, pinInput)) { unlocked = true; pinInput = "" } else pinError = true },
                            colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                        ) { Text("دخول") }
                    } else {
                        Button(
                            onClick = { showParental = false },
                            colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                        ) { Text("تم") }
                    }
                },
                dismissButton = { TextButton(onClick = { showParental = false }) { Text(stringResource(R.string.confirm_no), color = c.muted) } }
            )
        }

        // ---- Help / onboarding ----
        if (showHelp) {
            val isEn = SecureStore.appLocale(applicationContext) == "en"
            val items = if (isEn) listOf(
                "🎤 Mic" to "Tap and speak instead of typing. Tap again to stop.",
                "+ Attach" to "Send a photo (camera or gallery) or a .txt file. Qiri reads it, translates it, or answers questions about it.",
                "💻 Code help" to "Paste code or describe a bug. Qiri tells you the language and fixes it.",
                "🔎 Web search" to "Say “search for …” or ابحث عن — Qiri looks it up online.",
                "📵 Unknown caller" to "Enable it from the drawer: any stranger's call is auto-checked and you get a notification.",
                "👨‍👩‍👧 Parental Control" to "Set a PIN, then block any app for your kids. Needs “Enable app control”.",
                "📱 Enable app control" to "Lets Qiri open/tap/type in ANY app when you ask, e.g. “open WhatsApp and search Ahmed”.",
                "🎙️ “Ya Qiri” mode" to "A hands-free listening mode. Say the wake word, then your command.",
                "📁 Folders" to "Everything Qiri saves (scans, summaries, locations, call logs) is organized by folder.",
                "⚙️ Settings" to "Add your free/paid AI key here. Qiri detects the provider automatically.",
                "🌐 Language" to "Switches these menus only — Qiri still talks to you in Yemeni Arabic, that's who he is 😉"
            ) else listOf(
                "🎤 المايك" to "اضغط وتكلم بدل الكتابة. اضغط ثاني عشان توقف.",
                "+ إرفاق" to "ارسل صورة (كاميرا او معرض) او ملف نصي txt. القيري يقرأها، يترجمها، او يجاوبك عليها.",
                "💻 مساعدة برمجية" to "الصق كود او اشرح مشكلة. القيري يقول لك اي لغة برمجة وين المشكلة ويصلحها.",
                "🔎 البحث في النت" to "قل «ابحث عن ...» والقيري يدور لك في الانترنت.",
                "📵 كاشف الارقام المجهولة" to "فعّله من القائمة: اي رقم غريب يتصل عليك يتفحص تلقائي وتوصلك اشعار.",
                "👨‍👩‍👧 الرقابة الابوية" to "سوّ رمز سري، وبعدها احظر اي تطبيق على اطفالك. يحتاج «تفعيل التحكم بالتطبيقات».",
                "📱 تفعيل التحكم بالتطبيقات" to "يخلي القيري يفتح ويضغط ويكتب في اي تطبيق وقت ما تطلب، مثل «افتح واتساب وابحث عن أحمد».",
                "🎙️ وضع «يا قيري»" to "استماع بدون ما تضغط شي. قل كلمة النداء وبعدها امرك.",
                "📁 المجلدات" to "كل شي يحفظه القيري (فحوصات، ملخصات، مواقع، مكالمات) منظم حسب المجلد.",
                "⚙️ الاعدادات" to "ضيف مفتاحك (مجاني او مدفوع) من هنا. القيري يتعرف على نوعه تلقائي.",
                "🌐 اللغة" to "تغيّر القوائم بس — القيري يكلمك دايم باللهجة اليمنية، كذا هويته 😉"
            )
            AlertDialog(
                onDismissRequest = { showHelp = false },
                containerColor = c.panel, titleContentColor = c.text, textContentColor = c.text,
                title = { Text(stringResource(R.string.menu_help), fontFamily = FontFamily.Serif) },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()).heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items.forEach { (title, body) ->
                            Column {
                                Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = c.accent)
                                Text(body, fontSize = 13.sp, color = c.text, lineHeight = 19.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { showHelp = false }, colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)) {
                        Text(if (isEn) "Got it" else "تمام")
                    }
                }
            )
        }

        // ---- Trusted-mode warning (skips approval for calls/SMS/location) ----
        if (pendingTrustedConfirm) {
            AlertDialog(
                onDismissRequest = { pendingTrustedConfirm = false },
                containerColor = c.panel, titleContentColor = c.danger, textContentColor = c.text,
                title = { Text("⚡ تحذير قبل التفعيل") },
                text = {
                    Text(
                        "بهذا الوضع، القيري راح يتصل ويرسل رسائل ويشارك موقعك فوراً من غير ما يسألك تأكيد — حتى لو فهم كلامك غلط.\n\n" +
                            "استخدمه بس اذا انت متأكد وواثق من الاوامر الصوتية. تقدر ترجعه عادي أي وقت من نفس هذا الزر."
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            trustedMode = true
                            SecureStore.setTrustedMode(applicationContext, true)
                            pendingTrustedConfirm = false
                            addAssistant("فعّلت الوضع الموثوق ⚡ الحين انفّذ الاتصال والرسائل مباشرة بدون تأكيد.")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = c.danger, contentColor = Color.White)
                    ) { Text("فعّل على مسؤوليتي") }
                },
                dismissButton = { TextButton(onClick = { pendingTrustedConfirm = false }) { Text("الغاء", color = c.muted) } }
            )
        }
    }

    @Composable
    private fun Bubble(m: Msg) {
        val c = LocalPalette.current
        if (m.fromUser) {
            // user: soft rounded bubble, tap the pencil to edit and resend
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
                SelectionContainer {
                    Surface(color = c.userBubble, shape = RoundedCornerShape(20.dp), modifier = Modifier.widthIn(max = 320.dp)) {
                        Text(
                            m.text, color = c.text, fontSize = 15.sp, lineHeight = 24.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                        )
                    }
                }
                TextButton(onClick = { if (!busy) inputText = m.text }, enabled = !busy) {
                    Text("✏️ عدّل وارسل ثاني", color = c.muted, fontSize = 12.sp)
                }
            }
        } else {
            // assistant: plain text on the page, no bubble — with ```code``` fences rendered as code blocks
            val url = Regex("https://\\S+").find(m.text)?.value?.trimEnd(')', '.', '،', '"')
            var saved by remember { mutableStateOf(false) }
            var copied by remember { mutableStateOf(false) }
            val clipboard = LocalClipboardManager.current
            Column(Modifier.fillMaxWidth()) {
                SelectionContainer { RichText(m.text, c) }
                Row {
                    if (url != null) {
                        TextButton(onClick = {
                            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
                        }) { Text("🗺️ افتح الرابط", color = c.accent) }
                    }
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(m.text))
                        copied = true
                    }) { Text(if (copied) "✅ انسخ" else "📋 نسخ", color = c.accent) }
                    TextButton(onClick = {
                        tools.saveToAlQiriFile("المشاريع", "محفوظ_" + System.currentTimeMillis(), m.text)
                        saved = true
                    }) { Text(if (saved) "✅ انحفظ" else "💾 احفظ", color = c.accent) }
                }
            }
        }
    }

    /** Renders assistant text, drawing ```lang ... ``` fences as monospace code blocks instead of plain prose. */
    @Composable
    private fun RichText(text: String, c: Palette) {
        val parts = text.split("```")
        Column {
            parts.forEachIndexed { i, part ->
                if (part.isBlank()) return@forEachIndexed
                if (i % 2 == 1) {
                    val firstBreak = part.indexOf('\n')
                    val lang = if (firstBreak in 1..12) part.substring(0, firstBreak).trim() else ""
                    val code = if (firstBreak in 1..12) part.substring(firstBreak + 1) else part
                    Surface(
                        color = c.sidebar, shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            if (lang.isNotBlank()) Text(lang, fontSize = 11.sp, color = c.muted, fontWeight = FontWeight.Bold)
                            Text(
                                code.trim('\n'), color = c.text, fontSize = 13.sp, lineHeight = 19.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.horizontalScroll(rememberScrollState())
                            )
                        }
                    }
                } else {
                    Text(part.trim('\n'), color = c.text, fontSize = 15.5.sp, lineHeight = 26.sp, textAlign = TextAlign.Start)
                }
            }
        }
    }
}
