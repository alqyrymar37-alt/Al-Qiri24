package com.alqiri.legend

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * The agent's "hands": reads the screen and taps/types/scrolls in OTHER apps ("افتح واتساب وابحث عن...").
 * It only acts on tool calls chosen by the AI; parental control (below) also uses its screen events to
 * detect and block apps, independent of the AI.
 */
class QiriAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: QiriAccessibilityService? = null
        val connected = MutableStateFlow(false)
    }

    override fun onServiceConnected() {
        instance = this
        connected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            ParentalControl.onAppOpened(this, event.packageName?.toString())
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        connected.value = false
        return super.onUnbind(intent)
    }

    fun currentPackage(): String = rootInActiveWindow?.packageName?.toString() ?: "unknown"

    // ---------- reading ----------
    fun dumpScreen(): String {
        val root = rootInActiveWindow ?: return "ERROR: no active window (screen locked or protected app)."
        val sb = StringBuilder("app=${root.packageName}\n")
        var count = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || count >= 220) return
            if (n.isVisibleToUser) {
                val text = if (n.isPassword) "[hidden]" else n.text?.toString()?.take(100)
                val desc = n.contentDescription?.toString()?.take(100)
                if (!text.isNullOrBlank() || !desc.isNullOrBlank() || n.isClickable || n.isEditable) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    sb.append("- ").append(n.className?.toString()?.substringAfterLast('.') ?: "View")
                    if (!text.isNullOrBlank()) sb.append(" text=\"").append(text).append('"')
                    if (!desc.isNullOrBlank()) sb.append(" desc=\"").append(desc).append('"')
                    if (n.isEditable) sb.append(" [قابل للكتابة]")
                    if (n.isClickable) sb.append(" [قابل للضغط]")
                    sb.append(" @(${r.centerX()},${r.centerY()})\n")
                    count++
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    private fun firstMatch(n: AccessibilityNodeInfo?, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) firstMatch(n.getChild(i), pred)?.let { return it }
        return null
    }

    // ---------- acting ----------
    suspend fun tapText(q: String): String {
        val root = rootInActiveWindow ?: return "ERROR: no active window."
        val node = root.findAccessibilityNodeInfosByText(q).firstOrNull { it.isVisibleToUser }
            ?: firstMatch(root) {
                it.isVisibleToUser && (it.contentDescription?.toString()?.contains(q, true) == true ||
                    it.viewIdResourceName?.endsWith(q) == true)
            }
            ?: return "ERROR: ما لقيت عنصر بهذا الاسم «$q». اقرأ الشاشة وحاول من جديد."
        var target: AccessibilityNodeInfo? = node
        while (target != null && !target.isClickable) target = target.parent
        val ok = target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: run {
            val r = Rect(); node.getBoundsInScreen(r)
            tapAt(r.exactCenterX(), r.exactCenterY())
        }
        delay(700)
        return if (ok) "ضغطت على «$q» ✅" else "ERROR: الضغط على «$q» فشل."
    }

    suspend fun typeText(text: String, pressEnter: Boolean): String {
        val root = rootInActiveWindow ?: return "ERROR: no active window."
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: firstMatch(root) { it.isEditable && it.isVisibleToUser }
            ?: return "ERROR: ما لقيت خانة كتابة. اضغط على الخانة أول."
        if (node.isPassword) return "BLOCKED: خانات كلمة السر ممنوعة، خلّي المستخدم يكتبها بنفسه."
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && pressEnter && Build.VERSION.SDK_INT >= 30) {
            delay(250)
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        delay(500)
        return if (ok) "كتبت في الخانة ✅" else "ERROR: ما قدرت اكتب في هذي الخانة."
    }

    suspend fun scroll(direction: String): String {
        val root = rootInActiveWindow ?: return "ERROR: no active window."
        val forward = direction.equals("down", true) || direction.contains("تحت") || direction.contains("اسفل")
        val node = firstMatch(root) { it.isScrollable && it.isVisibleToUser }
        val ok = node?.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        ) ?: false
        if (!ok) {
            val w = resources.displayMetrics.widthPixels
            val h = resources.displayMetrics.heightPixels
            val p = Path().apply {
                if (forward) { moveTo(w / 2f, h * 0.7f); lineTo(w / 2f, h * 0.3f) }
                else { moveTo(w / 2f, h * 0.3f); lineTo(w / 2f, h * 0.7f) }
            }
            gesture(p, 300)
        }
        delay(600)
        return "سحبت الشاشة."
    }

    fun pressKey(key: String): String {
        val action = when {
            key.contains("رجوع") || key.contains("back") -> GLOBAL_ACTION_BACK
            key.contains("الرئيسية") || key.contains("home") -> GLOBAL_ACTION_HOME
            key.contains("حديث") || key.contains("recent") -> GLOBAL_ACTION_RECENTS
            else -> return "ERROR: زر غير معروف '$key'."
        }
        return if (performGlobalAction(action)) "تم الضغط." else "ERROR: ما قدرت اضغط الزر."
    }

    suspend fun tapAt(x: Float, y: Float): Boolean {
        val ok = gesture(Path().apply { moveTo(x, y) }, 60)
        delay(600)
        return ok
    }

    private suspend fun gesture(path: Path, durationMs: Long): Boolean = suspendCancellableCoroutine { cont ->
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        val started = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!started && cont.isActive) cont.resume(false)
    }
}
