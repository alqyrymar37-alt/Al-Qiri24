# القيري الأسطورة — Al-Qiri LEGEND
Kotlin + Jetpack Compose (target SDK 34). Arabic UI, RTL, dark + gold theme.
Voice in (SpeechRecognizer ar-YE), voice out (TextToSpeech ar), text in/out.

Files
- MainActivity.kt : the 8 functions (scanPhoneSecurityUltimate, saveToAlQiriFile, getAlQiriFiles,
                    dialAndSpeak / sendSmsToContact / findContactNumber, lookupCallerID, findMyPhone,
                    shareMyLocationWith / requestLocationFrom) + UI + voice
- Brain.kt        : Claude tool-use loop (online), Arabic rule-based router (offline), teacher mode
- SecureStore.kt  : API key stored encrypted

Safety: every call / SMS / location-share needs an on-screen approval (auto-deny after 2 min).

## مفاتيح مجانية مدعومة
القيري يتعرف تلقائياً على نوع المفتاح من شكله، تحط اي وحد منهم في الاعدادات:
- **Google Gemini (مجاني)**: يبدأ بـ AIza — احصل عليه من aistudio.google.com/apikey (زر مباشر داخل الاعدادات)
- **Groq (مجاني)**: يبدأ بـ gsk_ — من console.groq.com/keys
- **Claude (Anthropic, مدفوع)**: يبدأ بـ sk-ant-
- **OpenRouter**: يبدأ بـ sk-or-
- **اي خدمة متوافقة مع OpenAI**: تحتاج تدخل رابط الخدمة (Base URL) يدوياً

⚠️ تنبيه: في الطبقة المجانية من Gemini، جوجل ممكن تستخدم بياناتك لتحسين نماذجها. لا ترسل معلومات حساسة عبره.


## وضع «يا قيري» (استماع في الخلفية)
- ☰ ← «تشغيل وضع يا قيري». يظهر اشعار دائم فيه زر ايقاف.
- اطلع من التطبيق وقل: «يا قيري وين جوالي» — الاوامر الحساسة (اتصال/رسالة/مشاركة موقع) تنتظر «نفذ» او «الغاء» بالصوت.
- اذا الجوال مقفول بقفل (بصمة/رمز) ما ينفّذ شي: اندرويد ما يسمح لتطبيق يفك القفل، وحماية لك من اي شخص قريب.
- لتشتغل والجوال مقفول: فعّل Smart Lock. ولـ«وين جوالي» من الخلفية: صلاحية الموقع «السماح طوال الوقت».

## مفتوح المصدر
هذا المشروع بالكامل — كل ملف Kotlin وكل سطر — مو نسخة مبنية جاهزة، هو الكود المصدري نفسه اللي تبنيه انت.
رخصة MIT (ملف LICENSE)، يعني تقدر تعدّله، تشاركه، وتبنيه على جهازك كيف ما تبغى، بدون قيود.

## يشتغل بدون اي مفتاح API
بدون اي مفتاح (مجاني او مدفوع)، القيري يشتغل بمحرك محلي بالكامل (Brain.offline() في الكود) يغطي:
افحص جوالي، وين جوالي، الاتصال، الرسائل، من هذا الرقم، فتح التطبيقات، حفظ وعرض الملفات، تلخيص النصوص + اختبار تفاعلي،
حساب سريع (٢+٢، ٥٠٪ من ١٢٠...)، والوقت والتاريخ.
مفتاح API (مجاني من Gemini/Groq او مدفوع من Claude) يضيف فقط: فهم الكلام الحر غير المتوقع، ووصف/ترجمة الصور، والبحث في الانترنت —
هذي الأشياء تحتاج نموذج لغوي حقيقي (محلي او سحابي)، ما فيه طريقة حولها بدون واحد منهم.
